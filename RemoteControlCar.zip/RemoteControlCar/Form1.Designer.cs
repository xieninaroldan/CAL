﻿namespace RemoteControlCar
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_ul = new System.Windows.Forms.Button();
            this.btn_ur = new System.Windows.Forms.Button();
            this.btn_dl = new System.Windows.Forms.Button();
            this.btn_dr = new System.Windows.Forms.Button();
            this.btn_up = new System.Windows.Forms.Button();
            this.btn_down = new System.Windows.Forms.Button();
            this.btn_left = new System.Windows.Forms.Button();
            this.btn_right = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btn_connect = new System.Windows.Forms.Button();
            this.btn_disconnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_ul
            // 
            this.btn_ul.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ul.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ul.Location = new System.Drawing.Point(356, 246);
            this.btn_ul.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ul.Name = "btn_ul";
            this.btn_ul.Size = new System.Drawing.Size(98, 90);
            this.btn_ul.TabIndex = 1;
            this.btn_ul.Text = "↖";
            this.btn_ul.UseVisualStyleBackColor = false;
            this.btn_ul.Click += new System.EventHandler(this.btn_ul_Click);
            // 
            // btn_ur
            // 
            this.btn_ur.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ur.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ur.Location = new System.Drawing.Point(568, 246);
            this.btn_ur.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ur.Name = "btn_ur";
            this.btn_ur.Size = new System.Drawing.Size(98, 90);
            this.btn_ur.TabIndex = 2;
            this.btn_ur.Text = "↗";
            this.btn_ur.UseVisualStyleBackColor = false;
            this.btn_ur.Click += new System.EventHandler(this.btn_ur_Click);
            // 
            // btn_dl
            // 
            this.btn_dl.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_dl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dl.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dl.Location = new System.Drawing.Point(356, 442);
            this.btn_dl.Margin = new System.Windows.Forms.Padding(4);
            this.btn_dl.Name = "btn_dl";
            this.btn_dl.Size = new System.Drawing.Size(98, 90);
            this.btn_dl.TabIndex = 3;
            this.btn_dl.Text = "↙";
            this.btn_dl.UseVisualStyleBackColor = false;
            this.btn_dl.Click += new System.EventHandler(this.btn_dl_Click);
            // 
            // btn_dr
            // 
            this.btn_dr.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_dr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dr.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dr.Location = new System.Drawing.Point(568, 442);
            this.btn_dr.Margin = new System.Windows.Forms.Padding(4);
            this.btn_dr.Name = "btn_dr";
            this.btn_dr.Size = new System.Drawing.Size(98, 90);
            this.btn_dr.TabIndex = 4;
            this.btn_dr.Text = "↘";
            this.btn_dr.UseVisualStyleBackColor = false;
            this.btn_dr.Click += new System.EventHandler(this.btn_dr_Click);
            // 
            // btn_up
            // 
            this.btn_up.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_up.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_up.ForeColor = System.Drawing.Color.Black;
            this.btn_up.Location = new System.Drawing.Point(462, 246);
            this.btn_up.Margin = new System.Windows.Forms.Padding(4);
            this.btn_up.Name = "btn_up";
            this.btn_up.Size = new System.Drawing.Size(98, 90);
            this.btn_up.TabIndex = 6;
            this.btn_up.Text = "↑";
            this.btn_up.UseVisualStyleBackColor = false;
            this.btn_up.Click += new System.EventHandler(this.btn_up_Click);
            // 
            // btn_down
            // 
            this.btn_down.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_down.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_down.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.btn_down.Location = new System.Drawing.Point(462, 442);
            this.btn_down.Margin = new System.Windows.Forms.Padding(4);
            this.btn_down.Name = "btn_down";
            this.btn_down.Size = new System.Drawing.Size(98, 90);
            this.btn_down.TabIndex = 7;
            this.btn_down.Text = "↓";
            this.btn_down.UseVisualStyleBackColor = false;
            this.btn_down.Click += new System.EventHandler(this.btn_down_Click);
            // 
            // btn_left
            // 
            this.btn_left.BackColor = System.Drawing.Color.White;
            this.btn_left.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_left.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_left.ForeColor = System.Drawing.Color.Black;
            this.btn_left.Location = new System.Drawing.Point(356, 344);
            this.btn_left.Margin = new System.Windows.Forms.Padding(4);
            this.btn_left.Name = "btn_left";
            this.btn_left.Size = new System.Drawing.Size(98, 90);
            this.btn_left.TabIndex = 8;
            this.btn_left.Text = "←";
            this.btn_left.UseVisualStyleBackColor = false;
            this.btn_left.Click += new System.EventHandler(this.btn_left_Click);
            // 
            // btn_right
            // 
            this.btn_right.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_right.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_right.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_right.Location = new System.Drawing.Point(568, 344);
            this.btn_right.Margin = new System.Windows.Forms.Padding(4);
            this.btn_right.Name = "btn_right";
            this.btn_right.Size = new System.Drawing.Size(98, 90);
            this.btn_right.TabIndex = 9;
            this.btn_right.Text = "→";
            this.btn_right.UseVisualStyleBackColor = false;
            this.btn_right.Click += new System.EventHandler(this.btn_right_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(356, 37);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(310, 63);
            this.textBox1.TabIndex = 10;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(894, 565);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(116, 45);
            this.textBox2.TabIndex = 11;
            this.textBox2.Text = "Baudrate:";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(356, 116);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(94, 23);
            this.btn_connect.TabIndex = 12;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // btn_disconnect
            // 
            this.btn_disconnect.Location = new System.Drawing.Point(572, 116);
            this.btn_disconnect.Name = "btn_disconnect";
            this.btn_disconnect.Size = new System.Drawing.Size(94, 23);
            this.btn_disconnect.TabIndex = 13;
            this.btn_disconnect.Text = "Disconnect";
            this.btn_disconnect.UseVisualStyleBackColor = true;
            this.btn_disconnect.Click += new System.EventHandler(this.btn_disconnect_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(353, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "Baudrate:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1022, 622);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_disconnect);
            this.Controls.Add(this.btn_connect);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_right);
            this.Controls.Add(this.btn_left);
            this.Controls.Add(this.btn_down);
            this.Controls.Add(this.btn_up);
            this.Controls.Add(this.btn_dr);
            this.Controls.Add(this.btn_dl);
            this.Controls.Add(this.btn_ur);
            this.Controls.Add(this.btn_ul);
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_ul;
        private System.Windows.Forms.Button btn_ur;
        private System.Windows.Forms.Button btn_dl;
        private System.Windows.Forms.Button btn_dr;
        private System.Windows.Forms.Button btn_up;
        private System.Windows.Forms.Button btn_down;
        private System.Windows.Forms.Button btn_left;
        private System.Windows.Forms.Button btn_right;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.Button btn_disconnect;
        private System.Windows.Forms.Label label1;
    }
}

