﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RemoteControlCar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_ul_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_ur_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_dl_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_dr_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_up_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_down_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_left_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_right_Click(object sender, EventArgs e)
        {
           
        }

        private void MoveCar(string direction)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_connect_Click(object sender, EventArgs e)
        {

        }

        private void btn_disconnect_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
